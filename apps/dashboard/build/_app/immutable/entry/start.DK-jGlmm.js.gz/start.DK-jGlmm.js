import{l as o,a as r}from"../chunks/C9fAJV5Y.js";export{o as load_css,r as start};
